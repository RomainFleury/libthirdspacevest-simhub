#ifndef _TNTACTILEJACKET_
#define _TNTACTILEJACKET_

#define TJACKET_LIB_VERSION		(1b)		/* Version 1b */
#define NUMBER_CELLS			(8)			/* Total number of cells in the jacket */
//Flush params
#define FLUSH_ALL		(-1) //Flush All Effects
//Errors...
#define GLIB_OK			(0) //no error
#define GLIB_NOTINIT	(1) //Not Initialized, Call SetUpJacket()
#define GLIB_BADPARAM	(2) //Bad Param passed to function
#define GLIB_ERR_COMM	(3) //Communication with jacket Failed
#define GLIB_NO_EFF		(4)	//Invalid Predefined Effect
//Pre-defined library effects
typedef enum {

	E_MACHINEGUN_FRONT,
	E_MACHINEGUN_BACK,
	E_BIG_BLAST_FRONT,
	E_BIG_BLAST_BACK,
	E_SMALL_BLAST_FRONT,
	E_SMALL_BLAST_BACK,
	E_PISTOL_FRONT,
	E_PUNCH_FRONT,
	E_STAB_FRONT,
	E_SHOTGUN_FRONT,
	E_RIFLE_FRONT,
	E_PISTOL_BACK,
	E_PUNCH_BACK,
	E_STAB_BACK,
	E_SHOTGUN_BACK,
	E_RIFLE_BACK,
	E_LEFT_SIDE_HIT,
	E_RIGHT_SIDE_HIT,
	E_ACCELERATION,
	E_DECELERATION,
	E_LEFTTURN,
	E_RIGHTTURN,
	E_ACCELERATION_STOP,
	E_DECELERATION_STOP,
	E_LEFTTURN_STOP,
	E_RIGHTTURN_STOP

}TN_JEFFECTS;

#ifdef __cplusplus
extern "C" {
#endif


extern int __stdcall SetUpJacket();
extern void __stdcall TearDownJacket();
extern int __stdcall SetEffect(int nEffect);
extern int __stdcall SetEffect2(int speed,int actuator);
extern void __stdcall FlushBuffer(int actuator);
extern int __stdcall GetErrorCode();
extern bool __stdcall GetDevConnection();
extern void __stdcall GetErrorText(char* inbuffer, int size);
const int SentEffectNoWaitPreDef(const int nEffect);
const int SentEffectNoWait(const int speed, const int actuator);
const int GetPredefTime();
#ifdef __cplusplus
}
#endif

#endif /* _TNTACTILEJACKET_ */
