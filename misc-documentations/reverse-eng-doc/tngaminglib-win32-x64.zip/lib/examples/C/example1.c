/* --- include file */
#include "tngaming.h"

/* --- link library */
#pragma comment(lib,"tngaming.lib")


int main(int argc, char* argv[])
{
	/* Initailized gaming library */
	if (SetUpJacket()  != GLIB_OK)
	{
		printf(“Error: %s”, GetErrorText());
	}

	/* Send a predefined effect */
	if (SetEffect(E_MACHINEGUN_FRONT) != GLIB_OK)
	{
		printf(“Error: %s”, GetErrorText());
	}


	if (SetEffect2(10,1) != GLIB_OK)
	{
		printf(“Error: %s”, GetErrorText());
	}


	/* clean up and exit from gaming library */	
	TearDownJacket();
	

	return 0;
}
