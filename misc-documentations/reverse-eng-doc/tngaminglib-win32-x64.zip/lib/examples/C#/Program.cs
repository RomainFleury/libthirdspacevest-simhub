﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

// Reference the library functions from tngamgaming.dll
public class TNGamesLib
{
    [DllImport("tngamgaming.dll")]
    public static extern int SetUpJacket();
    [DllImport("tngamgaming.dll")]
    public static extern void TearDownJacket();
    [DllImport("tngamgaming.dll")]
    public static extern int SetEffect(int nEffect);
    [DllImport("tngamgaming.dll")]
    public static extern int SetEffect2(int speed, int actuator);
    [DllImport("tngamgaming.dll")]
    public static extern void FlushBuffer(int actuator);
    [DllImport("tngamgaming.dll")]
    public static extern int GetErrorCode();

}


namespace TNGamesExampleCS
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo cki;
            Int32 act = 0;
            Int32 spd = 0;
         
            do
            {   Console.WriteLine("Press Esc. to quit or any-other key to continue");

                cki = Console.ReadKey();
                if (cki.Key != ConsoleKey.Escape)
                {

                    Console.WriteLine("Enter target actuator (1-8):");
                    cki = Console.ReadKey();
                    if (Int32.TryParse(cki.KeyChar.ToString(), out act))
                    {

                        // TODO: Add validation                    }

                        Console.WriteLine("Enter pressure/speed value ( 1 - 100 ) and press enter:");
                        string tmpspd = Console.ReadLine();
                        if (Int32.TryParse(tmpspd, out spd))
                        {
                            // TODO: Add validation

                            // Simple send to vest

                            TNGamesLib.SetUpJacket();
                            TNGamesLib.SetEffect2(spd, act);
                            TNGamesLib.TearDownJacket();
                        }

                    }
                 
                }

            } while (cki.Key != ConsoleKey.Escape);
        }
    }
}
